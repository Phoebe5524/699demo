import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Settings, ShoppingCart, Plus, X, 
  Home, Calendar, User, Filter, Mail, Car, Clapperboard, 
  GraduationCap, PiggyBank, Sparkles, Utensils, LayoutGrid, Zap,
  History, ChevronDown, AlignJustify, Columns, Rows, GripVertical, Check, RefreshCcw,
  ArrowRight, ArrowLeft, MoveHorizontal
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

import { RAW_DATA } from './data'; 

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// === 日期格式化 ===
const formatDate = (dateStr) => {
  if (!dateStr) return '';
  const [y, m, d] = dateStr.split('-');
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return `${months[parseInt(m) - 1]} ${parseInt(d)}`;
};

// === 配置 ===
const CATEGORIES_CONFIG = {
  'Food': { icon: <Utensils size={14} />, color: 'bg-[#f6cccc]', label: 'Food' }, 
  'Transportation': { icon: <Car size={14} />, color: 'bg-[#fffdc0]', label: 'Trans' }, 
  'Shopping': { icon: <ShoppingCart size={14} />, color: 'bg-[#d8ccdd]', label: 'Shop' }, 
  'Entertainment': { icon: <Clapperboard size={14} />, color: 'bg-[#f7c7a6]', label: 'Fun' }, 
  'Personal Care': { icon: <Sparkles size={14} />, color: 'bg-[#d8f7fd]', label: 'Care' }, 
  'Education': { icon: <GraduationCap size={14} />, color: 'bg-[#bba0c6]', label: 'Edu' }, 
  'Savings': { icon: <PiggyBank size={14} />, color: 'bg-[#dbe3cb]', label: 'Save' }, 
  'Subscription': { icon: <Mail size={14} />, color: 'bg-[#bbecf3]', label: 'Sub' }, 
  'Misc': { icon: <Zap size={14} />, color: 'bg-[#babab9]', label: 'Misc' }, 
  'Income': { icon: <Plus size={14} />, color: 'bg-gray-800', label: 'Inc' }, 
};

const INITIAL_TRANSACTIONS = RAW_DATA.map((item, index) => ({
  id: index, 
  ...item,
  amount: Math.abs(item.amount),
}));

export default function App() {
  // === Data State ===
  const [transactions, setTransactions] = useState(INITIAL_TRANSACTIONS);
  
  // === UI View State ===
  const [viewMode, setViewMode] = useState('Month'); // Month, Biweekly, Weekly, Daily
  const [showViewMenu, setShowViewMenu] = useState(false);
  const [currentMonth, setCurrentMonth] = useState('November');
  
  // === Filter State ===
  const [spendingType, setSpendingType] = useState('ALL'); // ALL, Fixed, Flexible
  const [unit, setUnit] = useState(50);
  const [selectedEnvelopes, setSelectedEnvelopes] = useState([]); // Filter by Envelope
  const [isFilterOn, setIsFilterOn] = useState(true); // Toggle for applying filters
  const [showEnvelopeModal, setShowEnvelopeModal] = useState(false);
  const [sortType, setSortType] = useState('newest'); // Only used for "Recent" toggle

  // === Modal / Editing State ===
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [amount, setAmount] = useState('');
  const [memo, setMemo] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [formDate, setFormDate] = useState('');

  // === Drag Interaction State ===
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartX, setDragStartX] = useState(0);
  const [dragAmount, setDragAmount] = useState(0);
  const [dragPhase, setDragPhase] = useState('start'); // 'start', 'adding', 'reducing'
  const gridRef = useRef(null);

  // === Logic: Filter Data ===
  const filteredTransactions = useMemo(() => {
    let data = [...transactions];

    // 1. Filter by Spending Type (Fixed/Flexible)
    if (spendingType !== 'ALL') {
      data = data.filter(t => t.type === spendingType);
    } else {
      data = data.filter(t => t.category !== 'Income');
    }

    // 2. Filter by Envelopes (only if Filter is ON)
    if (isFilterOn && selectedEnvelopes.length > 0) {
      data = data.filter(t => selectedEnvelopes.includes(t.category));
    }

    // 3. Sort (Recent Button logic)
    data.sort((a, b) => {
      if (sortType === 'newest') return new Date(b.date) - new Date(a.date);
      return new Date(a.date) - new Date(b.date); // Simple toggle for now
    });

    return data;
  }, [transactions, spendingType, selectedEnvelopes, isFilterOn, sortType]);

  // === Logic: Toggle Envelope Selection (Max 5) ===
  const toggleEnvelope = (cat) => {
    if (selectedEnvelopes.includes(cat)) {
      setSelectedEnvelopes(prev => prev.filter(c => c !== cat));
    } else {
      if (selectedEnvelopes.length < 5) {
        setSelectedEnvelopes(prev => [...prev, cat]);
      }
    }
  };

  // === Logic: Drag to Add ===
  const handleDragStart = (e) => {
    // Only start drag if we clicked the "Insert" block
    setIsDragging(true);
    setDragPhase('start');
    setDragAmount(0);
    // Get initial X position (mouse or touch)
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    setDragStartX(clientX);
  };

  const handleDragMove = (e) => {
    if (!isDragging) return;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const deltaX = clientX - dragStartX;
    
    // Calculate amount based on Grid Width and Unit
    const pixelsPerUnit = 250; 
    const calculatedAmount = (Math.abs(deltaX) / pixelsPerUnit) * unit;
    
    setDragAmount(calculatedAmount);

    if (deltaX > 10) setDragPhase('adding');
    else if (deltaX < -10) setDragPhase('reducing');
    else setDragPhase('start');
  };

  const handleDragEnd = () => {
    if (isDragging && dragAmount > 0) {
      // Open modal with pre-filled amount
      handleAddClick(parseFloat(dragAmount.toFixed(2)));
    }
    setIsDragging(false);
    setDragPhase('start');
    setDragAmount(0);
  };

  // Add global event listeners for drag
  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleDragMove);
      window.addEventListener('mouseup', handleDragEnd);
      window.addEventListener('touchmove', handleDragMove);
      window.addEventListener('touchend', handleDragEnd);
    } else {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchmove', handleDragMove);
      window.removeEventListener('touchend', handleDragEnd);
    }
    return () => {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchmove', handleDragMove);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, [isDragging, dragStartX]);


  // === Modal Handlers ===
  const handleAddClick = (initialAmount = '') => {
    setEditingId(null);
    setAmount(initialAmount || '');
    setMemo('');
    setSelectedCategory(null);
    setFormDate(new Date().toISOString().split('T')[0]);
    setShowEditModal(true);
  };

  const handleEditClick = (transaction) => {
    setEditingId(transaction.id);
    setAmount(transaction.amount);
    setMemo(transaction.merchant);
    setSelectedCategory(transaction.category);
    setFormDate(transaction.date);
    setShowEditModal(true);
  };

  const handleSaveTransaction = () => {
    if (!amount || !selectedCategory || !formDate) return;
    const numAmount = parseFloat(amount);
    const newType = ['Food', 'Shopping', 'Entertainment'].includes(selectedCategory) ? 'Flexible' : 'Fixed'; // Mock logic

    if (editingId !== null) {
      setTransactions(prev => prev.map(t => t.id === editingId ? { ...t, category: selectedCategory, merchant: memo || selectedCategory, amount: numAmount, date: formDate, type: newType } : t));
    } else {
      setTransactions(prev => [...prev, { id: Date.now(), category: selectedCategory, merchant: memo || selectedCategory, amount: numAmount, date: formDate, type: newType }]);
    }
    setShowEditModal(false);
  };

  // === Grid Calculation ===
  const ROW_HEIGHT = 68;
  const CELLS_PER_ROW = 20;

  const displayBlocks = useMemo(() => {
    let blocks = [];
    let currentRowFill = 0;

    filteredTransactions.forEach(t => {
      const valuePerCell = unit / 20;
      let cellsNeeded = t.amount / valuePerCell;

      while (cellsNeeded > 0.01) {
        const spaceInCurrentRow = CELLS_PER_ROW - currentRowFill;
        let cellsToTake = Math.min(cellsNeeded, spaceInCurrentRow);
        
        if (cellsToTake > 0) {
            blocks.push({
                ...t, 
                uniqueKey: `${t.id}-${blocks.length}`, 
                widthPercent: (cellsToTake / CELLS_PER_ROW) * 100,
                isStart: blocks.length === 0 || blocks[blocks.length - 1].id !== t.id,
                color: CATEGORIES_CONFIG[t.category]?.color || 'bg-gray-400'
            });
        }
        cellsNeeded -= cellsToTake;
        currentRowFill += cellsToTake;
        if (currentRowFill >= CELLS_PER_ROW - 0.01) currentRowFill = 0;
      }
    });
    return blocks;
  }, [filteredTransactions, unit]);

  // Calculate row markers based on total height
  const rowCount = Math.ceil(displayBlocks.reduce((acc, b) => acc + b.widthPercent, 0) / 100) + 2; // +2 for buffer

  return (
    <div className="min-h-screen flex justify-center bg-gray-200 py-8 font-sans select-none text-brand-dark">
      <div className="w-full max-w-[390px] bg-white h-[844px] rounded-[40px] shadow-2xl overflow-hidden relative flex flex-col border-[8px] border-gray-100 box-content">
        
        {/* === 1. Top Header (Date Filter) === */}
        <header className="px-6 pt-12 pb-4 bg-white z-30">
          <div className="flex justify-between items-center mb-4">
            {/* Month Switcher */}
            <div className="flex items-center gap-1">
              <h1 className="text-3xl font-bold text-gray-900 tracking-tight">
                {viewMode === 'Weekly' ? <span>Nov <span className="text-red-500">17-30</span></span> : currentMonth}
              </h1>
              <ChevronDown size={20} className="text-gray-400 mt-1" />
            </div>

            <div className="flex gap-2">
               {/* View Mode Toggle */}
               <button 
                 onClick={() => setShowViewMenu(!showViewMenu)}
                 className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200"
               >
                 <LayoutGrid size={20}/>
               </button>
               {/* Ask Avatar */}
               <div className="h-10 px-3 rounded-full bg-red-100 flex items-center gap-2 text-sm font-bold text-red-500">
                  Ask! 
                  <div className="w-6 h-6 rounded-full bg-red-500 flex items-center justify-center text-white text-[10px]">🤖</div>
               </div>
            </div>
          </div>

          {/* View Mode Dropdown (Mock) */}
          {showViewMenu && (
            <div className="absolute right-6 top-24 bg-gray-100 rounded-xl p-1 shadow-lg flex flex-col gap-1 z-50 w-32 animate-slide-up">
               {['Biweekly', 'Weekly', 'Daily'].map(m => (
                 <button key={m} onClick={() => {setViewMode(m); setShowViewMenu(false)}} className="px-3 py-2 text-sm font-medium text-left hover:bg-white rounded-lg flex justify-between">
                   {m}
                   {m === 'Weekly' && <Rows size={14}/>}
                   {m === 'Daily' && <AlignJustify size={14}/>}
                   {m === 'Biweekly' && <Columns size={14}/>}
                 </button>
               ))}
            </div>
          )}
        </header>

        {/* === 2. & 6. Filter / Drag Banner === */}
        <div className="px-6 pb-2 z-30 relative h-14">
          {!isDragging ? (
            // Standard Filter Bar
            <div className="flex justify-between items-center animate-slide-up">
              <div className="flex gap-2">
                {['ALL', 'Fixed', 'Flexible'].map(type => (
                  <button 
                    key={type}
                    onClick={() => setSpendingType(type)}
                    className={cn(
                      "px-4 py-2 rounded-xl text-xs font-bold transition-all",
                      spendingType === type ? "bg-gray-800 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                    )}
                  >
                    {type === 'ALL' ? 'ALL' : (type === 'Fixed' ? <><LayoutGrid size={12} className="inline mr-1"/>Fixed</> : <><Zap size={12} className="inline mr-1"/>Flexible</>)}
                  </button>
                ))}
              </div>
              
              <button 
                onClick={() => setUnit(unit === 20 ? 50 : 20)}
                className="bg-[#E5E5EA] px-3 py-2 rounded-xl text-xs font-bold text-blue-600 hover:bg-gray-300"
              >
                {unit} <ChevronDown size={12} className="inline"/>
              </button>
            </div>
          ) : (
            // Dragging Banner
            <div className={cn(
              "absolute inset-x-6 top-0 bottom-2 rounded-2xl flex items-center justify-between px-4 font-bold text-sm shadow-sm transition-colors",
              dragPhase === 'adding' ? "bg-yellow-200 text-yellow-900 border border-yellow-400" :
              dragPhase === 'reducing' ? "bg-blue-100 text-blue-900 border border-blue-300" : "bg-yellow-50 text-yellow-800 border border-yellow-200"
            )}>
               <div className="flex items-center gap-2">
                  {dragPhase === 'start' && <span>Drag to start</span>}
                  {dragPhase === 'adding' && <span className="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded">Adding</span>}
                  {dragPhase === 'reducing' && <span className="bg-blue-500 text-white text-[10px] px-1.5 py-0.5 rounded">Reducing</span>}
                  
                  {dragPhase !== 'start' && <span>Roughly ${dragAmount.toFixed(2)}</span>}
               </div>
               
               <div className="flex gap-1">
                 {dragPhase === 'adding' && <ArrowRight size={16}/>}
                 {dragPhase === 'reducing' && <ArrowLeft size={16}/>}
                 {dragPhase === 'start' && <MoveHorizontal size={16}/>}
               </div>
            </div>
          )}
        </div>

        {/* ================= 5. Grid with Row Labels ================= */}
        <div 
          className="flex-1 overflow-y-auto custom-scrollbar bg-white relative"
          ref={gridRef}
        >
          <div className="min-h-full relative">
            {/* Grid Lines */}
            <div 
              className="absolute inset-0 pointer-events-none z-20 mx-6 border-r border-[#C7C7CC]"
              style={{
                backgroundSize: `20% ${ROW_HEIGHT}px, 5% ${ROW_HEIGHT}px, 100% ${ROW_HEIGHT}px`,
                backgroundImage: `
                  linear-gradient(to right, #C7C7CC 1px, transparent 1px),
                  linear-gradient(to right, rgb(220, 220, 225) 0.5px, transparent 0.5px),
                  linear-gradient(to bottom, #C7C7CC 1px, transparent 1px)
                `
              }}
            ></div>

            {/* Row Labels (Right Side) */}
            <div className="absolute right-1 top-0 bottom-0 flex flex-col items-center pointer-events-none z-10 pt-[68px]">
               {Array.from({ length: rowCount }).map((_, i) => (
                 <div key={i} className="h-[68px] flex items-end justify-end pr-1 text-[8px] text-gray-400 font-medium">
                   {(i + 1) * unit}
                 </div>
               ))}
            </div>

            {/* Content Layer */}
            <div className="relative flex flex-wrap content-start px-6 pt-[1px]">
              {displayBlocks.map((block) => (
                <div 
                  key={block.uniqueKey}
                  onClick={() => !isDragging && handleEditClick(block)}
                  className={cn("h-[68px] relative transition-all hover:brightness-105 overflow-hidden cursor-pointer", block.color)}
                  style={{ width: `${block.widthPercent}%` }}
                >
                  {block.isStart && block.widthPercent > 12 && (
                    <div className="absolute inset-0 z-30 pointer-events-none p-1.5">
                      <span className="absolute top-1.5 left-1.5 text-[9px] font-bold text-black leading-none opacity-80">{formatDate(block.date)}</span>
                      <div className="absolute top-1.5 right-1.5 text-black opacity-80">{React.cloneElement(CATEGORIES_CONFIG[block.category].icon, { size: 12 })}</div>
                      <span className="absolute bottom-1.5 left-1.5 text-[11px] font-extrabold text-black leading-none opacity-90">${block.amount}</span>
                    </div>
                  )}
                </div>
              ))}
              
              {/* Insert Block (Trigger for Drag) */}
              <div 
                onMouseDown={handleDragStart}
                onTouchStart={handleDragStart}
                className={cn(
                  "h-[68px] flex flex-col items-center justify-center text-gray-500 text-xs cursor-pointer border border-dashed border-gray-300 transition-colors z-30",
                  isDragging ? "bg-yellow-100 border-yellow-400" : "bg-gray-50 hover:bg-gray-100"
                )}
                style={{ width: isDragging ? `${(dragAmount/unit)*20*5}%` : '20%', minWidth: '20%' }}
              >
                {!isDragging && <Plus size={16} className="mb-1"/>}
                <span className="text-[10px] font-bold">{isDragging ? 'Insert...' : 'Insert'}</span>
              </div>
            </div>
          </div>

          {/* === 3. Floating Menu (Reorganized) === */}
          <div className="sticky bottom-6 float-right right-6 flex flex-col gap-4 z-40 mb-4 mr-4 items-end">
             {/* 1. Envelope / Budget Toggle */}
             <div className="bg-gray-100/90 backdrop-blur-md p-1.5 rounded-[20px] flex flex-col items-center gap-4 py-3 shadow-lg border border-white/50 w-14">
                <button 
                  onClick={() => setShowEnvelopeModal(true)}
                  className="flex flex-col items-center gap-1 group w-full"
                >
                   <div className="w-9 h-9 bg-white rounded-xl shadow-sm flex items-center justify-center text-gray-700 border border-gray-200">
                     <Mail size={18}/>
                   </div>
                   <span className="text-[8px] font-bold text-gray-500">Envelope</span>
                </button>

                {/* 👇 修复点：这里使用了正确的 isFilterOn */}
                <button 
                  onClick={() => setIsFilterOn(!isFilterOn)}
                  className="flex flex-col items-center gap-1 group w-full"
                >
                   <div className={cn("w-8 h-8 rounded-full flex items-center justify-center transition-colors", isFilterOn ? "text-blue-600 bg-blue-100" : "text-gray-400")}>
                     <Filter size={18} />
                   </div>
                   <span className={cn("text-[8px] font-bold", isFilterOn ? "text-blue-600" : "text-gray-400")}>
                     {isFilterOn ? "On" : "Off"}
                   </span>
                </button>
             </div>

             {/* 2. Recent (Moved to bottom, separate) */}
             <button 
               onClick={() => setSortType(prev => prev === 'newest' ? 'oldest' : 'newest')}
               className="w-14 h-14 bg-gray-800 rounded-[22px] shadow-xl flex flex-col items-center justify-center text-white gap-0.5 hover:bg-gray-900 transition active:scale-95"
             >
                <History size={20} className={sortType === 'oldest' ? "rotate-180" : ""}/>
                <span className="text-[8px] font-medium">Recent</span>
             </button>
          </div>
        </div>

        {/* Bottom Nav */}
        <div className="bg-white border-t border-gray-100 px-8 py-4 flex justify-between items-end text-[10px] font-medium text-gray-400 h-20 pb-6 z-30 relative">
          <button className="flex flex-col items-center gap-1 text-black"><Home size={24} fill="black" />Home</button>
          <button className="flex flex-col items-center gap-1 hover:text-black"><Calendar size={24} />Nov 10</button>
          <button className="flex flex-col items-center gap-1 hover:text-black"><User size={24} />My</button>
        </div>

        {/* === 3. Envelope Modal (Bottom Sheet) === */}
        {showEnvelopeModal && (
          <div className="absolute inset-0 z-50 flex flex-col justify-end">
            <div className="absolute inset-0 bg-black/20 backdrop-blur-[1px]" onClick={() => setShowEnvelopeModal(false)}></div>
            <div className="bg-white rounded-t-[30px] p-6 animate-slide-up shadow-2xl relative h-[60%] flex flex-col">
               <div className="flex justify-between items-start mb-2">
                 <div>
                   <h2 className="text-xl font-bold text-gray-900">Filter by Envelope</h2>
                   <p className="text-xs text-gray-400">Subtitle here type it</p>
                 </div>
                 <button onClick={() => setShowEnvelopeModal(false)}><X size={24} className="text-gray-400"/></button>
               </div>

               <div className="flex-1 overflow-y-auto grid grid-cols-2 gap-3 content-start py-4">
                  {Object.keys(CATEGORIES_CONFIG).filter(k => k !== 'Income').map(cat => {
                    const isSelected = selectedEnvelopes.includes(cat);
                    const config = CATEGORIES_CONFIG[cat];
                    return (
                      <button 
                        key={cat}
                        onClick={() => toggleEnvelope(cat)}
                        className={cn(
                          "flex items-center justify-between px-4 py-3 rounded-2xl border transition-all",
                          isSelected ? `${config.color} border-transparent` : "bg-white border-gray-100 hover:border-gray-300"
                        )}
                      >
                         <div className="flex items-center gap-2">
                            <div className={cn("w-6 h-6 rounded-full flex items-center justify-center text-xs", isSelected ? "bg-white/50 text-black" : "bg-gray-100 text-gray-500")}>
                              {React.cloneElement(config.icon, { size: 14 })}
                            </div>
                            <span className={cn("text-sm font-bold", isSelected ? "text-black" : "text-gray-700")}>{cat}</span>
                         </div>
                         {isSelected ? <Check size={16} className="text-black"/> : <Plus size={16} className="text-gray-300"/>}
                      </button>
                    )
                  })}
               </div>

               <div className="pt-4 flex gap-3">
                  <button onClick={() => setSelectedEnvelopes([])} className="w-14 h-14 rounded-2xl bg-gray-200 flex items-center justify-center text-gray-600 hover:bg-gray-300">
                    <RefreshCcw size={20} />
                  </button>
                  <button onClick={() => setShowEnvelopeModal(false)} className="flex-1 bg-gray-800 text-white font-bold rounded-2xl text-sm shadow-lg hover:bg-gray-900">
                    {selectedEnvelopes.length}/5 View Results
                  </button>
               </div>
            </div>
          </div>
        )}

        {/* === 4. Add/Edit Modal (Clean UI) === */}
        {showEditModal && (
          <div className="absolute inset-0 z-50 flex flex-col bg-gray-50 animate-slide-up">
            {/* Modal Header */}
            <header className="px-6 pt-12 pb-2 flex justify-between items-center bg-white">
               <button onClick={() => setShowEditModal(false)}><ChevronDown size={28} className="text-gray-400 rotate-90"/></button>
               <h2 className="text-lg font-bold text-gray-900">{editingId ? 'Review' : 'Review'}</h2>
               <div className="px-3 py-1 rounded-full bg-indigo-600 text-white text-xs font-bold flex items-center gap-1">
                 <Sparkles size={10}/> Ask?
               </div>
            </header>

            <div className="flex-1 overflow-y-auto px-6 pt-6">
               {/* Amount */}
               <div className="flex items-center justify-center mb-8 relative">
                 <span className="text-4xl font-bold text-gray-400 mr-1">$</span>
                 <input 
                   type="number" 
                   value={amount} 
                   onChange={(e) => setAmount(e.target.value)} 
                   placeholder="0.00" 
                   className="bg-transparent text-6xl font-extrabold text-black outline-none w-auto text-center placeholder:text-gray-200 min-w-[120px]" 
                 />
                 <div className="w-1 h-12 bg-red-500 ml-2 animate-pulse"></div>
               </div>

               {/* Details List */}
               <div className="bg-white rounded-2xl p-4 mb-8 shadow-sm">
                  <div className="flex justify-between items-center py-2 border-b border-gray-100">
                    <span className="text-sm font-bold text-gray-900">Date</span>
                    <input type="date" value={formDate} onChange={(e) => setFormDate(e.target.value)} className="text-sm font-medium text-blue-600 bg-transparent outline-none text-right"/>
                  </div>
                  <div className="flex justify-between items-center py-2 pt-4">
                    <span className="text-sm font-bold text-gray-900">Memo</span>
                    <input type="text" value={memo} onChange={(e) => setMemo(e.target.value)} placeholder="What is for?" className="text-sm font-medium text-blue-600 bg-transparent outline-none text-right placeholder:text-blue-300"/>
                  </div>
               </div>

               {/* Categories Grid */}
               <div className="mb-4 flex justify-between items-center">
                 <h3 className="font-bold text-lg">Envelope</h3>
                 <div className="flex items-center gap-1 text-xs text-gray-400"><History size={12}/> Recent</div>
               </div>
               
               <div className="grid grid-cols-3 gap-3 mb-24">
                  {/* Add Button */}
                  <button className="aspect-square rounded-2xl bg-gray-200/50 flex flex-col items-center justify-center gap-2 text-gray-500">
                    <Plus size={24}/>
                    <span className="text-xs font-bold">Add</span>
                  </button>

                  {Object.keys(CATEGORIES_CONFIG).filter(k => k !== 'Income').map((catKey) => {
                     const config = CATEGORIES_CONFIG[catKey];
                     const isSelected = selectedCategory === catKey;
                     return (
                        <button 
                          key={catKey} 
                          onClick={() => setSelectedCategory(catKey)} 
                          className={cn(
                            "aspect-square rounded-2xl flex flex-col items-center justify-center gap-2 transition-all relative border-[3px]", 
                            isSelected ? "bg-white border-pink-400 shadow-md" : "bg-white border-transparent"
                          )}
                        >
                          <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", isSelected ? "bg-pink-100 text-pink-500" : "bg-yellow-50 text-yellow-600")}>
                             {React.cloneElement(config.icon, { size: 18 })}
                          </div>
                          <span className="text-[10px] font-bold text-gray-700">{config.label}</span>
                        </button>
                     )
                  })}
               </div>
            </div>

            {/* Bottom Action */}
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-white border-t border-gray-100 flex gap-4">
               <button className="w-14 h-14 rounded-2xl bg-gray-200 flex flex-col items-center justify-center text-[10px] font-bold text-gray-500 gap-1 hover:bg-gray-300">
                 <div className="w-4 h-4 bg-gray-400 rounded-sm"></div>
                 Save
               </button>
               <button 
                 onClick={handleSaveTransaction}
                 className="flex-1 bg-gray-800 text-white font-bold rounded-2xl text-lg shadow-xl hover:bg-gray-900"
               >
                 Looks good!
               </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}